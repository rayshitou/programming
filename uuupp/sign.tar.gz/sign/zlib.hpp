#pragma once

#include "string.hpp"

namespace fc 
{

  string zlib_compress(const string& in);

} // namespace fc
