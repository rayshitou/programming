#include <stdio.h>
#include "sign.hpp"

int main(int argc, char **argv){
	sign(NULL, 0, NULL, 0);
        printf("hell0\n");
	return 0;
}
